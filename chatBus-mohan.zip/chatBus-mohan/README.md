# ChatBus
Reatime distributed chat system.


# Images
![ChatBus](https://github.com/ErlToys/chatBus/blob/feat-chatbus-client/images/chatbus1.png)


UI build using google polymer !


# Quick Start

Build client
    $ cd apps/chat_client/polymer
    $ bower intsall

Build App
    $ make
    $ make console


server running at localhost:9090
